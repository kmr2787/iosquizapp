
import UIKit

class ResultsViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var resultsLabel: UILabel!
    
    var noCorrect: Int = 0
    var total: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // sonuçları ayarlama
        resultsLabel.text = "Doğru Yapılan Soru \(noCorrect) Adettir"
        print(total)
        print(noCorrect)
        
        // Doğru olan soruların yüzdesini hesaplayın
        var percentRight = ((Double(noCorrect)) / (Double(total)))
        percentRight = percentRight * 100
        
        // Kullanıcıya doğru mesaj verdiğiniz soruların yüzdesine göre farklı mesajlar
        var title: String = ""
        if(percentRight < 40) {
            title = "Başarısız"
        } else if(percentRight < 70) {
            title = ":)"
        } else {
            title = "Güzel Bir Testi"
        }
        titleLabel.text = title
        // Görünümü yükledikten sonra herhangi bir ek kurulum yapın.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
