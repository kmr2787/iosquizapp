# QuizApp 
created at the 2018 Girls Who Code iPhone App Development Course at Harvey Mudd College

App quizzes you on your knowledge of Taylor Swift albums.

![Screenshot1](AppPhotos/Photo1.png)
![Screenshot2](AppPhotos/Photo2.png)
![Screenshot3](AppPhotos/Photo3.png)
![Screenshot4](AppPhotos/Photo4.png)

